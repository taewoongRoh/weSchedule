function httpError(data, status, headers, config) {
    alert('server error' + status);
    //w = window.open();
   // w.document.write(data);
}

