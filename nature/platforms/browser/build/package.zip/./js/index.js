var app = {

    initialize: function() {
        // Common events are: 'load', 'deviceready', 'offline', and 'online'.
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },

    onDeviceReady: function() {
        // The scope of 'this' is the event.
    
    }    
};

app.initialize();