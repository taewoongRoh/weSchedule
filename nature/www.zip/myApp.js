var app = angular.module('myApp', [ 'ngRoute', 'mobile-angular-ui', 'mobile-angular-ui.gestures' ]);

app.run(function($transform) {
    window.$transform = $transform;
});

app.config(function($routeProvider) {
    $routeProvider.when('/',      { templateUrl : 'home.html', reloadOnSearch : false, controller: 'LoginController' });
    $routeProvider.when('/schedule', { templateUrl : 'schedule.html', reloadOnSearch : false });
    $routeProvider.when('/alarm', { templateUrl : 'alarm.html', reloadOnSearch : false });
   });

app.controller('MainController', function($rootScope, $scope) {

    $scope.swiped = function(direction) {
        alert('Swiped ' + direction);
    };

    // Needed for the loading screen
    $rootScope.$on('$routeChangeStart', function() {
        $rootScope.loading = true;
    });

    $rootScope.$on('$routeChangeSuccess', function() {
        $rootScope.loading = false;
    });

});


app.controller('LoginController', function($scope,$location) {

    $scope.login = function() {
        if ($scope.email !== $scope.password) {
            $scope.loginMessage = "비밀번호 불일치";
        } else {
            $scope.loginMessage = "로그인 성공";
            $location.path('#/')
        }
    }

});